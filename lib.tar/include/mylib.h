#ifndef MYLIB_H
#define MYLIB_H

#include <string>

using  std::string;

class MyLib
{

public:
    string sayHello(const char* name);
    MyLib();
};

#endif // MYLIB_H
